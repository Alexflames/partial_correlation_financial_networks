A: correlation
B: partial correlation
Data: Russian Stock Market
